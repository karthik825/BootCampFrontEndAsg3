var employeesData; //Local varible for the employee data
var tableBody = $('#employeeTable tbody'); //referece to the table body

//fetch data from api to variable
$(document).ready(function () {
    $.ajax({
        url: 'https://dummy.restapiexample.com/api/v1/employees',
        type: 'GET',
        dataType: 'json',
        success: function (res) {
            //console.log(res);
            employeesData = res.data
            populateTable();
        },
        error: function () {
            alert('Error fetching data.');
        }
    });
});

//populate table with employeeData
function populateTable() {
    tableBody.empty();
    employeesData.forEach(function (employee) {
        tableBody.append(
            '<tr>' +
            '<td>' + employee.id + '</td>' +
            '<td>' + employee.employee_name + '</td>' +
            '<td>' + employee.employee_salary + '</td>' +
            '<td>' + employee.employee_age + '</td>' +
            '<td>' + employee.profile_image + '</td>' +
            '<td><button class="delete-button" data-id="' + employee.id + '">Delete</button></td>' +
            '</tr>'
        );
    });

}

//delete employee
$('#employeeTable').on('click', '.delete-button', function () {
    var id = $(this).data('id');
    console.log(id);
    employeesData = employeesData.filter(function (employee) {
        return employee.id !== id;
    });
    populateTable();
});

//filter employee
function filterEmployee() {
    tableBody.empty();
    const id = document.getElementById('empId').value;
    //console.log(id);
    employeesData.forEach(function (employee) {
        if (employee.id == id) {
            tableBody.append(
                '<tr>' +
                '<td>' + employee.id + '</td>' +
                '<td>' + employee.employee_name + '</td>' +
                '<td>' + employee.employee_salary + '</td>' +
                '<td>' + employee.employee_age + '</td>' +
                '<td>' + employee.profile_image + '</td>' +
                '</tr>'
            );
        }
    });
}


//add employee
$('#employee-form').submit(function (event) {
    event.preventDefault();
    var name = $('#name').val();
    var salary = $('#salary').val();
    var age = $('#age').val();
    var profileImage = "";

    var maxId = 0;
    employeesData.forEach(function (employee) {
        if (employee.id > maxId) {
            maxId = employee.id;
        }
    });
    var newId = maxId + 1;

    var newEmployee = {
        "id": newId,
        "employee_name": name,
        "employee_salary": salary,
        "employee_age": age,
        "profile_image": profileImage
    };
    employeesData.push(newEmployee);
    populateTable();
});

//disable the add employee button when id field is not empty
$('#id').on('input', function () {
    var id = $(this).val();
    if (id) {
        $('#add-employee').prop('disabled', true);
    } else {
        $('#add-employee').prop('disabled', false);
    }
});

//update employee
$('#update-button').click(function () {
    var id = $('#id').val();
    var name = $('#name').val();
    var salary = $('#salary').val();
    var age = $('#age').val();
    var profileImage = "";

    var updatedEmployee = {
        "id": id,
        "employee_name": name,
        "employee_salary": salary,
        "employee_age": age,
        "profile_image": profileImage
    };

    var index = employeesData.findIndex(function (employee) {
        return employee.id == id;
    });

    if (index !== -1) {
        employeesData[index] = updatedEmployee;
        populateTable();
    } else {
        alert('Employee not found.');
    }
});