﻿using EMPH3703_Scenario3.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace EMPH3697_Scenario3.Controllers
{
    public class ProjectsController : ApiController
    {
        private readonly string connectionString = "Data Source=.\\SQLEXPRESS;Initial Catalog=WideWorldImporters;Integrated Security=True";


        [HttpGet]
        public HttpResponseMessage GetProjects()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT * FROM dbo.Projects";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        connection.Open();

                        DataTable dt = new DataTable();
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        adapter.Fill(dt);

                        List<Project> projects = new List<Project>();
                        foreach (DataRow row in dt.Rows)
                        {
                            var project = new Project
                            {
                                ProjectID = Convert.ToInt32(row["ProjectID"]),
                                Name = row["Name"].ToString(),
                                Status = row["Status"].ToString(),
                                Revenue = Convert.ToDecimal(row["Revenue"])
                            };
                            projects.Add(project);
                        }

                        return Request.CreateResponse(HttpStatusCode.OK, projects);
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
        [HttpGet]
        [Route("api/projects/{projectId}")]
        public HttpResponseMessage GetProjectById(int projectId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "SELECT ProjectID, Name, Status, Revenue FROM Projects WHERE ProjectID = @ProjectID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProjectID", projectId);
                        connection.Open();

                        DataTable dt = new DataTable();
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        adapter.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            DataRow row = dt.Rows[0];
                            var project = new Project
                            {
                                ProjectID = Convert.ToInt32(row["ProjectID"]),
                                Name = row["Name"].ToString(),
                                Status = row["Status"].ToString(),
                                Revenue = Convert.ToDecimal(row["Revenue"])
                            };
                            return Request.CreateResponse(HttpStatusCode.OK, project);
                        }
                        else
                        {
                            return Request.CreateErrorResponse(HttpStatusCode.NotFound, $"Project with ID {projectId} not found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpPost]
        public HttpResponseMessage AddProject([FromBody] Project project)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Projects (Name, Status, Revenue) VALUES (@Name, @Status, @Revenue)";
                    Console.WriteLine(project);
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Name", project.Name);
                        command.Parameters.AddWithValue("@Status", project.Status);
                        command.Parameters.AddWithValue("@Revenue", project.Revenue);

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            return Request.CreateResponse(HttpStatusCode.OK, "Project added successfully.");
                        }
                        else
                        {
                            return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, "Failed to add project.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpPut]
        [Route("api/projects/update")]
        public HttpResponseMessage UpdateProject([FromBody] Project project)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "UPDATE Projects SET Name = @Name, Status = @Status, Revenue = @Revenue WHERE ProjectID = @ProjectID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Name", project.Name);
                        command.Parameters.AddWithValue("@Status", project.Status);
                        command.Parameters.AddWithValue("@Revenue", project.Revenue);
                        command.Parameters.AddWithValue("@ProjectID", project.ProjectID);

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            return Request.CreateResponse(HttpStatusCode.OK, $"Project {project.ProjectID} updated successfully.");
                        }
                        else
                        {
                            return Request.CreateErrorResponse(HttpStatusCode.NotFound, $"Project with ID {project.ProjectID} not found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }

        [HttpDelete]
        public HttpResponseMessage DeleteProject([FromBody] int projectId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "DELETE FROM Projects WHERE ProjectID = @ProjectID";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@ProjectID", projectId);

                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            return Request.CreateResponse(HttpStatusCode.OK, $"Project {projectId} deleted.");
                        }
                        else
                        {
                            return Request.CreateErrorResponse(HttpStatusCode.NotFound, $"Project with ID {projectId} not found.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
            }
        }
    }
}