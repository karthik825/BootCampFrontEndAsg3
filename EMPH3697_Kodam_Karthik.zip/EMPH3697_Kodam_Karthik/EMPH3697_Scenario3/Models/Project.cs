﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EMPH3697_Scenario3.Models
{
    public class Project
    {
        public int ProjectID { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public decimal Revenue { get; set; }
    }
}