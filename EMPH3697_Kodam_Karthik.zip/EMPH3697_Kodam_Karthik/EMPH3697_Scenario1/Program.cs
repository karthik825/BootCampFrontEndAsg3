﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

public static class EmailValidator
{
    public static bool IsValidEmail(string email)
    {
        // Regex pattern for a simple email validation
        string pattern = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";
        return Regex.IsMatch(email, pattern);
    }
}

public class Partner
{
    private string partnerContactEmail;
    public int PartnerId { get; set; }
    public string PartnerName { get; set; }
    public string PartnerContactEmail
    {
        get => partnerContactEmail;
        set
        {
            if (!EmailValidator.IsValidEmail(value))
            {
                throw new ArgumentException("Invalid email format", nameof(value));
            }

            partnerContactEmail = value;
        }
    }
    public string PartnerGeography { get; set; }
    public List<string> PartnerSpecializations { get; set; }

    public Partner(int partnerId, string partnerName, string partnerContactEmail, string partnerGeography, List<string> partnerSpecializations)
    {
        PartnerId = partnerId;
        PartnerName = partnerName;
        PartnerContactEmail = partnerContactEmail;
        PartnerGeography = partnerGeography;
        PartnerSpecializations = partnerSpecializations;
    }

    public void AddSpecialization(string specialization)
    {
        if (!PartnerSpecializations.Contains(specialization))
        {
            PartnerSpecializations.Add(specialization);
        }
    }

    public void RemoveSpecialization(string specialization)
    {
        PartnerSpecializations.Remove(specialization);
    }

    public void UpdatePartnerGeography(string newGeography)
    {
        if (string.IsNullOrWhiteSpace(newGeography))
        {
            throw new ArgumentException("Geography cannot be null or empty");
        }

        PartnerGeography = newGeography;
    }

    public override string ToString()
    {
        return $"Partner ID: {PartnerId}, Partner Name: {PartnerName}, Partner Contact Email: {PartnerContactEmail}, Partner Geography: {PartnerGeography}";
    }
}

public class PartnerAccountManager
{
    private string email;
    private string managerEmail;

    public int EmployeeId { get; set; }
    public string Email
    {
        get => email;
        set
        {
            if (!EmailValidator.IsValidEmail(value))
            {
                throw new ArgumentException("Invalid email format", nameof(value));
            }

            email = value;
        }
    }
    public string ManagerEmail
    {
        get => managerEmail;
        set
        {
            if (!EmailValidator.IsValidEmail(value))
            {
                throw new ArgumentException("Invalid email format", nameof(value));
            }

            managerEmail = value;
        }
    }
    public string Specialization { get; set; }

    public PartnerAccountManager(int employeeId, string email, string managerEmail, string specialization)
    {
        EmployeeId = employeeId;
        Email = email;
        ManagerEmail = managerEmail;
        Specialization = specialization;
    }

    public override string ToString()
    {
        return $"Employee ID: {EmployeeId}, Email: {Email}, Manager Email: {ManagerEmail}, Specialization: {Specialization}";
    }
}
public class ManagedPartner : Partner
{
    public DateTime ManagedFrom { get; set; }
    public PartnerAccountManager PartnerAccountManager { get; set; }

    public ManagedPartner(int partnerId, string partnerName, string partnerContactEmail, string partnerGeography,
                          List<string> partnerSpecializations, DateTime managedFrom, PartnerAccountManager partnerAccountManager)
                          : base(partnerId, partnerName, partnerContactEmail, partnerGeography, partnerSpecializations)
    {
        ManagedFrom = managedFrom;
        PartnerAccountManager = partnerAccountManager;
    }

    public void UpdatePartnerAccountManager(PartnerAccountManager newManager)
    {
        if (newManager == null)
        {
            throw new ArgumentNullException(nameof(newManager), "PartnerAccountManager cannot be null");
        }

        if (string.IsNullOrWhiteSpace(newManager.Email))
        {
            throw new ArgumentException("PartnerAccountManager Email cannot be null or empty", nameof(newManager.Email));
        }

        if (string.IsNullOrWhiteSpace(newManager.ManagerEmail))
        {
            throw new ArgumentException("PartnerAccountManager ManagerEmail cannot be null or empty", nameof(newManager.ManagerEmail));
        }

        if (string.IsNullOrWhiteSpace(newManager.Specialization))
        {
            throw new ArgumentException("PartnerAccountManager Specialization cannot be null or empty", nameof(newManager.Specialization));
        }

        PartnerAccountManager = newManager;
    }

    public override string ToString()
    {
        return base.ToString() + $", Managed From: {ManagedFrom}, Partner Account Manager: {PartnerAccountManager}";
    }
}

public class Program
{
    public static void Main()
    {
        // Test Partner class methods
        var partner = new Partner(1, "Partner Name", "partner@example.com", "Geography", new List<string>());
        partner.AddSpecialization("Specialization 1");
        partner.RemoveSpecialization("Specialization 1");
        partner.UpdatePartnerGeography("New Geography");

        // Test PartnerAccountManager class methods
        var manager = new PartnerAccountManager(1, "manager@example.com", "manager@example.com", "Specialization");

        // Test ManagedPartner class methods
        var managedPartner = new ManagedPartner(1, "Partner Name", "partner@example.com", "Geography", new List<string>(), DateTime.Now, manager);
        managedPartner.UpdatePartnerAccountManager(new PartnerAccountManager(2, "newmanager@example.com", "newmanager@example.com", "New Specialization"));

        Console.WriteLine(partner);
        Console.WriteLine(manager);
        Console.WriteLine(managedPartner);

        Console.WriteLine("All methods tested successfully.");
    }
}